import React, { useState } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

// Reusable Card Component
function StudyCard({ subject, sessions, onIncrease, onDecrease, onReset }) {
  return (
    <View style={styles.card}>
      <Text style={styles.subject}>Subject: {subject}</Text>
      <Text style={styles.sessionText}>Sessions: {sessions}</Text>

      <View style={styles.buttonRow}>
        {/* Decrease Button */}
        <TouchableOpacity
          style={[styles.circleButton, { backgroundColor: '#00b894' }]}
          onPress={onDecrease}
        >
          <Text style={styles.buttonText}>-</Text>
        </TouchableOpacity>

        {/* Increase Button */}
        <TouchableOpacity
          style={[styles.circleButton, { backgroundColor: '#6c5ce7' }]}
          onPress={onIncrease}
        >
          <Text style={styles.buttonText}>+</Text>
        </TouchableOpacity>

        {/* Reset Button */}
        <TouchableOpacity
          style={[styles.circleButton, { backgroundColor: '#d63031' }]}
          onPress={onReset}
        >
          <Text style={styles.resetText}>Reset</Text>
        </TouchableOpacity>
      </View>

      {/* Messages */}
      {sessions >= 5 && sessions < 10 && (
        <Text style={styles.message}>📘 Keep it up!</Text>
      )}
      {sessions >= 10 && <Text style={styles.goal}>🎯 Goal Achieved!</Text>}
    </View>
  );
}

export default function App() {
  const [flutter, setFlutter] = useState(0);
  const [dart, setDart] = useState(0);
  const [react, setReact] = useState(0);

  const total = flutter + dart + react;

  const resetAll = () => {
    setFlutter(0);
    setDart(0);
    setReact(0);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>📚 Study Session Tracker</Text>
      <Text style={styles.totalText}>Total Sessions: {total}</Text>

      <StudyCard
        subject="Flutter"
        sessions={flutter}
        onIncrease={() => setFlutter(flutter + 1)}
        onDecrease={() => setFlutter(flutter > 0 ? flutter - 1 : 0)}
        onReset={() => setFlutter(0)}
      />

      <StudyCard
        subject="Dart"
        sessions={dart}
        onIncrease={() => setDart(dart + 1)}
        onDecrease={() => setDart(dart > 0 ? dart - 1 : 0)}
        onReset={() => setDart(0)}
      />

      <StudyCard
        subject="React"
        sessions={react}
        onIncrease={() => setReact(react + 1)}
        onDecrease={() => setReact(react > 0 ? react - 1 : 0)}
        onReset={() => setReact(0)}
      />

      <TouchableOpacity style={styles.resetAllBtn} onPress={resetAll}>
        <Text style={styles.resetAllText}>Reset All</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f4f8',
    padding: 40,
    paddingTop: 50,
  },
  header: {
    textAlign: 'center',
    fontSize: 28,
    fontWeight: '800',
    color: '#2d3436',
    marginBottom: 8,
  },
  totalText: {
    textAlign: 'center',
    fontSize: 18,
    color: '#636e72',
    marginBottom: 15,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#ffffff',
    padding: 30,
    borderRadius: 18,
    marginVertical: 15,
    alignItems: 'center',
    shadowColor: '#95afc0',
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6,
    borderWidth: 1,
    borderColor: '#dfe6e9',
  },
  subject: {
    fontSize: 22,
    fontWeight: '700',
    color: '#2d3436',
  },
  sessionText: {
    fontSize: 18,
    marginVertical: 10,
    color: '#636e72',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 10,
    columnGap: 15,
  },
  circleButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 3,
  },
  buttonText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  resetText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  message: {
    marginTop: 10,
    color: '#6c5ce7',
    fontWeight: '600',
    fontSize: 16,
  },
  goal: {
    marginTop: 10,
    color: '#00b894',
    fontWeight: '700',
    fontSize: 16,
  },
  resetAllBtn: {
    backgroundColor: '#0984e3',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 60,
    marginTop: 15,
  },
  resetAllText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
});
